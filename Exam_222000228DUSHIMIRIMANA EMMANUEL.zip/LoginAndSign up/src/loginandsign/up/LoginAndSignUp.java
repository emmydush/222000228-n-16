
package loginandsign.up;

import loginandsignup.Login;


public class LoginAndSignUp {

   
    public static void main(String[] args) {
        // TODO code application logic here
          Login LoginFrame = new Login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);  
    }
    
    }
    

